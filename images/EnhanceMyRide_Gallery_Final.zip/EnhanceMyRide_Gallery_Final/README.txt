Enhance My Ride Gallery — Web-Ready Images

All images are WebP and resized for website use (maximum dimension 1600px).

Lexus/
  Before/  = Lexus before/detail-condition photos
  After/   = Lexus completed-detail photos
Mercedes/
  Before/  = Mercedes before/detail-condition photos
  After/   = Mercedes completed-detail photos

Suggested GitHub gallery upload structure:
images/gallery/...
